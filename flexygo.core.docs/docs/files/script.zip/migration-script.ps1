#!/usr/bin/env powershell
<#
.SYNOPSIS
    Migrate a Flexygo project from the old master layout (v1.2.0.21) to the new master release layout (v1.3.0.1).

.DESCRIPTION
    Applies a template-driven migration with version validation, git safety guard,
    and structured logging. Applies changes by default after interactive confirmation.
    Use -DryRun to preview without writing any files.

.PARAMETER ProjectPath
    Path to the project root (contains .sln file). Defaults to current directory.

.PARAMETER ProjectName
    Project name (for example: "FlexygoCoreProduct"). If omitted, it is auto-detected from .sln.

.PARAMETER DryRun
    Preview mode. When specified, no files are written.

.PARAMETER MinVersion
    Minimum required Flexygo version for precheck.

.PARAMETER TargetVersion
    Version used to replace {{Version}} placeholders in templates.
    When omitted or empty, auto-detected from the project's Flexygo package references.
#>

param(
    [string]$ProjectPath = (Get-Location).Path,
    [string]$ProjectName = $null,
    [switch]$DryRun,
    [string]$MinVersion = "1.2.0.21",
    [string]$TargetVersion = ""
)

Set-StrictMode -Version 3.0
$ErrorActionPreference = "Stop"

$script:LOG = @()
$script:WARNINGS = @()
$script:ERRORS = @()
$script:LOG_FILE = ""

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO", "WARN", "ERROR", "SUCCESS")][string]$Level = "INFO"
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$timestamp] [$Level] $Message"

    switch ($Level) {
        "SUCCESS" { Write-Host $line -ForegroundColor Green }
        "WARN" { Write-Host $line -ForegroundColor Yellow }
        "ERROR" { Write-Host $line -ForegroundColor Red }
        default { Write-Host $line }
    }

    $script:LOG += $line
}

function Write-Warning-Custom {
    param([string]$Message)
    Write-Log -Message $Message -Level "WARN"
    $script:WARNINGS += $Message
}

function Write-Error-Custom {
    param([string]$Message)
    Write-Log -Message $Message -Level "ERROR"
    $script:ERRORS += $Message
}

function Write-Success {
    param([string]$Message)
    Write-Log -Message $Message -Level "SUCCESS"
}

function Save-LogFile {
    if (-not $script:LOG_FILE) {
        return
    }

    $dir = Split-Path -Parent $script:LOG_FILE
    if (-not (Test-Path $dir)) {
        New-Item -Path $dir -ItemType Directory -Force | Out-Null
    }

    [System.IO.File]::WriteAllLines($script:LOG_FILE, $script:LOG, [System.Text.UTF8Encoding]::new($false))
    Write-Host ""
    Write-Host "Log file: $script:LOG_FILE" -ForegroundColor Cyan
}

function Ensure-GitIgnoreScriptEntry {
    param([string]$Path)
    # Pre-flight: ensure 'script/' is excluded from git tracking before the dirty-state check.
    # The migration script lives in script/ which sits alongside the project; git would otherwise
    # flag it as an untracked change and block execution.
    $gitignorePath = Join-Path $Path ".gitignore"
    $entry = "script/"

    if (Test-Path $gitignorePath) {
        $existingLines = @(Get-Content -Path $gitignorePath -Encoding UTF8)
        if ($existingLines -match '^script/?(\*)?$') {
            Write-Log ".gitignore already contains a 'script' entry - pre-flight skipped."
            return
        }
        $existingLines += $entry
        [System.IO.File]::WriteAllLines($gitignorePath, $existingLines, [System.Text.UTF8Encoding]::new($false))
    }
    else {
        [System.IO.File]::WriteAllLines($gitignorePath, @($entry), [System.Text.UTF8Encoding]::new($false))
    }
    Write-Log "Pre-flight: added '$entry' to .gitignore"

    # If inside an existing git repo, stage and commit so the dirty-check sees a clean tree.
    $gitAvailablePreFlight = $null -ne (Get-Command git -ErrorAction SilentlyContinue)
    if (-not $gitAvailablePreFlight) { return }

    $insideRepo = $false
    try {
        $checkResult = git -C $Path rev-parse --is-inside-work-tree 2>&1
        $insideRepo = ($LASTEXITCODE -eq 0 -and "$checkResult".Trim() -eq "true")
    }
    catch { }

    if ($insideRepo) {
        git -C $Path add ".gitignore" 2>&1 | ForEach-Object { Write-Log $_ }
        $commitOut = git -C $Path commit -m "chore: add script/ to .gitignore (pre-migration)" 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Success "Pre-flight: committed .gitignore update - working tree will be clean for migration check."
        }
        else {
            Write-Warning-Custom "Pre-flight .gitignore commit failed (non-fatal): $commitOut"
        }
    }
}

function Ensure-GitRepository {
    param([string]$Path)

    $gitAvailable = $null -ne (Get-Command git -ErrorAction SilentlyContinue)
    if (-not $gitAvailable) {
        Write-Warning-Custom "git not found in PATH - skipping repository safety check."
        return
    }

    $isInsideRepo = $false
    try {
        $result = git -C $Path rev-parse --is-inside-work-tree 2>&1
        $isInsideRepo = ($LASTEXITCODE -eq 0 -and "$result".Trim() -eq "true")
    }
    catch { }

    if ($isInsideRepo) {
        Write-Log "Git repository detected at: $Path"
        $statusOutput = git -C $Path status --porcelain 2>&1
        if ($LASTEXITCODE -ne 0) {
            Write-Warning-Custom "Could not read git status - proceeding without check."
            return
        }
        if ($statusOutput) {
            throw @"
MIGRATION BLOCKED: Uncommitted local changes detected.

Please commit, stash, or discard your changes before running the migration:

  git stash                          - stash changes temporarily
  git add . ; git commit -m 'wip'    - commit current state
  git checkout -- .                  - discard all changes (irreversible)

Re-run the migration after your working tree is clean.
"@
        }
        Write-Success "Working tree is clean - safe to migrate."
    }
    else {
        Write-Log "No git repository found - initializing a local repository to preserve pre-migration state..."
        try {
            git -C $Path init 2>&1 | ForEach-Object { Write-Log $_ }
            git -C $Path add --all 2>&1 | ForEach-Object { Write-Log $_ }
            $commitResult = git -C $Path commit -m "chore: pre-migration state (auto-committed by migration tool)" 2>&1
            if ($LASTEXITCODE -ne 0) {
                Write-Warning-Custom "git commit returned non-zero: $commitResult"
            }
            else {
                Write-Success "Pre-migration state committed to new local git repository."
            }
        }
        catch {
            Write-Warning-Custom "Failed to initialize git repository: $_"
        }
    }
}

function Resolve-ComparableVersion {
    param([string]$VersionText)

    if (-not $VersionText) {
        return $null
    }

    $match = [regex]::Match($VersionText, '^(\d+(?:\.\d+){1,3})')
    if (-not $match.Success) {
        return $null
    }

    try {
        return [version]$match.Groups[1].Value
    }
    catch {
        return $null
    }
}

function Resolve-TemplateRoot {
    $scriptDir = Split-Path -Parent $PSCommandPath
    return Join-Path $scriptDir "templates"
}

function Detect-ProjectName {
    if ($ProjectName) {
        Write-Log "ProjectName provided: $ProjectName"
        return $ProjectName
    }

    $slnFiles = @(Get-ChildItem -Path $ProjectPath -Filter "*.sln" -File)
    if ($slnFiles.Count -eq 0) {
        Write-Error-Custom "Cannot auto-detect ProjectName: no .sln file found in $ProjectPath"
        return $null
    }

    $detectedName = [System.IO.Path]::GetFileNameWithoutExtension($slnFiles[0].Name)
    Write-Log "Detected ProjectName: $detectedName"
    return $detectedName
}

function Test-ProjectPath {
    if (-not (Test-Path $ProjectPath)) {
        Write-Error-Custom "Project path not found: $ProjectPath"
        return $false
    }

    $slnFiles = @(Get-ChildItem -Path $ProjectPath -Filter "*.sln" -File)
    if ($slnFiles.Count -eq 0) {
        Write-Error-Custom "No .sln file found in $ProjectPath"
        return $false
    }

    if ($slnFiles.Count -gt 1) {
        Write-Warning-Custom "Multiple .sln files found; using first: $($slnFiles[0].Name)"
    }

    Write-Log "Found solution: $($slnFiles[0].Name)"
    return $true
}

function Get-FlexygoPackageReferences {
    param([string]$ProjectFilePath)

    [xml]$xml = Get-Content -Path $ProjectFilePath -Encoding UTF8 -Raw
    $references = @()

    $packageNodes = @($xml.SelectNodes("//*[local-name()='PackageReference']"))
    foreach ($packageRef in $packageNodes) {
        $include = [string]$packageRef.GetAttribute("Include")
        if (-not $include -or $include -notlike "Flexygo.*") {
            continue
        }

        $versionValue = [string]$packageRef.GetAttribute("Version")
        if (-not $versionValue) {
            foreach ($child in @($packageRef.ChildNodes)) {
                if ($child.Name -eq "Version") {
                    $versionValue = [string]$child.InnerText
                    break
                }
            }
        }

        $references += [pscustomobject]@{
            Include = $include
            Version = $versionValue
        }
    }

    return $references
}

function Detect-FlexygoVersion {
    <#
    .SYNOPSIS
        Auto-detect the Flexygo package version from the project's .csproj files.

    .DESCRIPTION
        Reads Flexygo package references from the Backend .csproj (primary) and returns
        the version of Flexygo.Backend. Falls back to any Flexygo.* package if
        Flexygo.Backend is not found.
    #>
    param(
        [string]$ProjectName,
        [string]$ProjectPath
    )

    $backendProj = Join-Path $ProjectPath "$ProjectName.Backend\$ProjectName.Backend.csproj"

    if (-not (Test-Path $backendProj)) {
        Write-Warning-Custom "Cannot auto-detect Flexygo version: Backend project not found at $backendProj"
        return $null
    }

    try {
        $refs = @(Get-FlexygoPackageReferences -ProjectFilePath $backendProj)
    }
    catch {
        Write-Warning-Custom "Failed to parse $backendProj for version detection: $_"
        return $null
    }

    if ($refs.Count -eq 0) {
        Write-Warning-Custom "No Flexygo.* package references found in Backend project."
        return $null
    }

    # Prefer Flexygo.Backend (the core package that dictates the version)
    $flexygoRef = $refs | Where-Object { $_.Include -eq "Flexygo.Backend" } | Select-Object -First 1

    # Fallback: any Flexygo.* package
    if (-not $flexygoRef) {
        $flexygoRef = $refs | Select-Object -First 1
        Write-Log "Flexygo.Backend not found; using $($flexygoRef.Include) version $($flexygoRef.Version) for {{Version}} placeholder."
    }
    else {
        Write-Log "Detected Flexygo version: $($flexygoRef.Version) (from $($flexygoRef.Include))"
    }

    return $flexygoRef.Version
}

function Test-VersionRequirement {
    param(
        [string]$ProjectFilePath,
        [version]$MinComparableVersion
    )

    if (-not (Test-Path $ProjectFilePath)) {
        Write-Warning-Custom "Project file not found (skipped): $ProjectFilePath"
        return $true
    }

    try {
        $refs = @(Get-FlexygoPackageReferences -ProjectFilePath $ProjectFilePath)
    }
    catch {
        Write-Error-Custom "Failed to parse $ProjectFilePath : $_"
        return $false
    }

    if ($refs.Count -eq 0) {
        Write-Log "No Flexygo.* dependencies found in $([System.IO.Path]::GetFileName($ProjectFilePath))"
        return $true
    }

    $isValid = $true
    foreach ($ref in $refs) {
        $comparable = Resolve-ComparableVersion -VersionText $ref.Version
        if (-not $comparable) {
            Write-Error-Custom "$($ref.Include) has invalid version '$($ref.Version)' in $ProjectFilePath"
            $isValid = $false
            continue
        }

        if ($comparable -lt $MinComparableVersion) {
            Write-Error-Custom "$($ref.Include) is version $($ref.Version) (minimum required: $MinVersion)"
            $isValid = $false
        }
        else {
            Write-Log "OK: $($ref.Include) version $($ref.Version)"
        }
    }

    return $isValid
}

function Validate-Preconditions {
    Write-Log "Phase 1: Validating preconditions..."

    $minComparable = Resolve-ComparableVersion -VersionText $MinVersion
    if (-not $minComparable) {
        Write-Error-Custom "Invalid MinVersion value: $MinVersion"
        return $false
    }

    $filesToValidate = @(
        "$ProjectName.Backend/$ProjectName.Backend.csproj",
        "$ProjectName.Frontend/$ProjectName.Frontend.csproj",
        "$ProjectName.Processes/$ProjectName.Processes.csproj",
        "$ProjectName.Conf.Database/$ProjectName.Conf.Database.sqlproj"
    )

    $allValid = $true
    foreach ($relativePath in $filesToValidate) {
        $fullPath = Join-Path $ProjectPath $relativePath
        if (-not (Test-VersionRequirement -ProjectFilePath $fullPath -MinComparableVersion $minComparable)) {
            $allValid = $false
        }
    }

    if (-not $allValid) {
        Write-Error-Custom @"
MIGRATION BLOCKED: Version requirements not met.

Install "Flexygo Developer Tools" and run "Update to Latest Version"
before retrying this migration.
"@
        return $false
    }

    Write-Success "All preconditions passed"
    return $true
}

function Get-TemplateMappings {
    return @(
        [pscustomobject]@{ Template = "Backend.nuspec"; Destination = "{{ProjectName}}.Backend/{{ProjectName}}.Backend.nuspec" },
        [pscustomobject]@{ Template = "Frontend.nuspec"; Destination = "{{ProjectName}}.Frontend/{{ProjectName}}.Frontend.nuspec" },
        [pscustomobject]@{ Template = "Library.nuspec"; Destination = "{{ProjectName}}.Backend/{{ProjectName}}.Library.nuspec" },
        [pscustomobject]@{ Template = "Conf.Database.nuspec"; Destination = "{{ProjectName}}.Conf.Database/{{ProjectName}}.Conf.Database.nuspec" },
        [pscustomobject]@{ Template = "appsettings.json.backend"; Destination = "{{ProjectName}}.Backend/conf/appsettings.json" },
        [pscustomobject]@{ Template = "appsettings.Development.json.backend"; Destination = "{{ProjectName}}.Backend/conf/appsettings.Development.json" },
        [pscustomobject]@{ Template = "appsettings.json.frontend"; Destination = "{{ProjectName}}.Frontend/conf/appsettings.json" },
        [pscustomobject]@{ Template = "appsettings.Development.json.frontend"; Destination = "{{ProjectName}}.Frontend/conf/appsettings.Development.json" },
        [pscustomobject]@{ Template = "Backend.props"; Destination = "{{ProjectName}}.Backend/buildTransitive/{{ProjectName}}.Backend.props" },
        [pscustomobject]@{ Template = "Frontend.props"; Destination = "{{ProjectName}}.Frontend/buildTransitive/{{ProjectName}}.Frontend.props" },
        [pscustomobject]@{ Template = "Conf.Database.props"; Destination = "{{ProjectName}}.Conf.Database/buildTransitive/{{ProjectName}}.Conf.Database.props" },
        [pscustomobject]@{ Template = "Conf.Database.targets"; Destination = "{{ProjectName}}.Conf.Database/buildTransitive/{{ProjectName}}.Conf.Database.targets" },
        [pscustomobject]@{ Template = "Data.Database.props"; Destination = "{{ProjectName}}.Data.Database/buildTransitive/{{ProjectName}}.Data.Database.props" },
        [pscustomobject]@{ Template = "Data.Database.nuspec"; Destination = "{{ProjectName}}.Data.Database/{{ProjectName}}.Data.Database.nuspec" },
        [pscustomobject]@{ Template = "tsconfig.json"; Destination = "{{ProjectName}}.Frontend/tsconfig.json" },
        [pscustomobject]@{ Template = "Conf.Database.local.publish.xml"; Destination = "{{ProjectName}}.Conf.Database/local.publish.xml" },
        [pscustomobject]@{ Template = "Data.Database.local.publish.xml"; Destination = "{{ProjectName}}.Data.Database/local.publish.xml" },
        [pscustomobject]@{ Template = "nuget.config"; Destination = "nuget.config" },
        [pscustomobject]@{ Template = "extensions.json"; Destination = ".vscode/extensions.json" },
        [pscustomobject]@{ Template = "wwwroot.css.README.md"; Destination = "{{ProjectName}}.Frontend/wwwroot/{{ProjectName}}/css/README.md" },
        [pscustomobject]@{ Template = "wwwroot.js.README.md"; Destination = "{{ProjectName}}.Frontend/wwwroot/{{ProjectName}}/js/README.md" },
        # ── Phase 8: Data.Database merge infrastructure ──
        [pscustomobject]@{ Template = "Data.Database.mergeSSDTScripts.ps1"; Destination = "{{ProjectName}}.Data.Database/tools/install/mergeSSDTScripts.ps1" },
        [pscustomobject]@{ Template = "Data.Database.targets"; Destination = "{{ProjectName}}.Data.Database/buildTransitive/{{ProjectName}}.Data.Database.targets" }
    )
}

function Get-ParametrizedContent {
    param(
        [string]$TemplateContent,
        [string]$EffectiveProjectName,
        [string]$EffectiveTargetVersion
    )

    $result = $TemplateContent
    $result = $result.Replace("{{ProjectName}}", $EffectiveProjectName)
    $result = $result.Replace("{{Version}}", $EffectiveTargetVersion)

    if ($result -match "{{[^}]+}}") {
        Write-Warning-Custom "Unresolved placeholder detected after template rendering."
    }

    return $result
}

function New-MigrationAction {
    param(
        [string]$TemplatePath,
        [string]$DestinationPath,
        [string]$RenderedContent
    )

    $destinationExists = Test-Path $DestinationPath

    $currentContent = ""
    if ($destinationExists) {
        $currentContent = Get-Content -Path $DestinationPath -Raw -Encoding UTF8
    }

    $requiresWrite = (-not $destinationExists) -or ($currentContent -ne $RenderedContent)

    return [pscustomobject]@{
        ActionType        = "Copy"
        TemplatePath      = $TemplatePath
        DestinationPath   = $DestinationPath
        DestinationExists = $destinationExists
        RequiresWrite     = $requiresWrite
        RenderedContent   = $RenderedContent
    }
}

function Remove-DirectoryForcefully {
    param([string]$Path)

    # Attempt 1: clear read-only flags then .NET recursive delete
    try {
        Get-ChildItem -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue |
        ForEach-Object { try { $_.Attributes = 'Normal' } catch { } }
        [System.IO.Directory]::Delete($Path, $true)
        return
    }
    catch { }

    # Attempt 2: robocopy mirror to empty the directory, then remove the shell
    $emptyTemp = Join-Path $env:TEMP ([System.Guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Path $emptyTemp -Force | Out-Null
    robocopy $emptyTemp $Path /MIR /NFL /NDL /NJH /NJS /NC /NS /NP /R:1 /W:0 | Out-Null
    Remove-Item -Path $emptyTemp -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $Path -Force -Recurse -ErrorAction SilentlyContinue

    if (-not (Test-Path $Path)) { return }

    # Attempt 3: cmd rmdir /s /q
    $p = Start-Process -FilePath "cmd.exe" -ArgumentList "/c", "rmdir", "/s", "/q", "`"$Path`"" `
        -NoNewWindow -Wait -PassThru
    if (-not (Test-Path $Path)) { return }

    throw "Failed to delete directory after all attempts: $Path"
}

function New-DeletionAction {
    param(
        [string]$TargetPath,
        [bool]$IsDirectory = $false
    )

    $targetExists = Test-Path $TargetPath

    return [pscustomobject]@{
        ActionType   = "Delete"
        TargetPath   = $TargetPath
        IsDirectory  = $IsDirectory
        TargetExists = $targetExists
    }
}

function Get-DeletionMappings {
    # Returns deletion targets with {{ProjectName}} tokens (resolved by Plan-Migration).
    # D-04: {{ProjectName}}.Frontend/wwwroot/{{ProjectName}}/ is intentionally ABSENT.
    $wwwroot = "{{ProjectName}}.Frontend/wwwroot"
    return @(
        # D-01: install.map.json x 4 project roots
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Backend/install.map.json"; IsDirectory = $false },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Frontend/install.map.json"; IsDirectory = $false },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/install.map.json"; IsDirectory = $false },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Data.Database/install.map.json"; IsDirectory = $false },
        # D-02: wwwroot/ subdirectories (NuGet staticwebassets - no longer source)
        [pscustomobject]@{ RelativePath = "$wwwroot/css"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "$wwwroot/docs"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "$wwwroot/img"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "$wwwroot/js"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "$wwwroot/mobile"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "$wwwroot/reports"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "$wwwroot/Scripts"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "$wwwroot/xsl"; IsDirectory = $true },
        # D-03: wwwroot/ root files
        [pscustomobject]@{ RelativePath = "$wwwroot/favicon.ico"; IsDirectory = $false },
        [pscustomobject]@{ RelativePath = "$wwwroot/Flexygo.Frontend.styles.css"; IsDirectory = $false },
        [pscustomobject]@{ RelativePath = "$wwwroot/manifest.json"; IsDirectory = $false },
        [pscustomobject]@{ RelativePath = "$wwwroot/tsconfig.json"; IsDirectory = $false },
        [pscustomobject]@{ RelativePath = "$wwwroot/versions.json"; IsDirectory = $false },
        # D-05: Conf.Database/build/ - targets moved to buildTransitive/ in Phase 2
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/build"; IsDirectory = $true },
        # D-06: Backend/updater/ - build artifacts from parent package
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Backend/updater"; IsDirectory = $true },
        # D-07: Frontend/updater/ - same reason
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Frontend/updater"; IsDirectory = $true },
        # D-08: Orphan UnitTest runtime artifact in Backend
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Backend/Flexygo.UnitTest.deps.json"; IsDirectory = $false },
        # D-09: Orphan UnitTest runtime artifact in Backend
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Backend/Flexygo.UnitTest.runtimeconfig.json"; IsDirectory = $false },
        # D-10: MailLicense.xml - now contentFile from Flexygo.Backend nupkg
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Backend/MailLicense.xml"; IsDirectory = $false },
        # D-11: bin/ and obj/ from all 7 project directories (regenerated by dotnet build)
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Backend/bin"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Backend/obj"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Frontend/bin"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Frontend/obj"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/bin"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/obj"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Data.Database/bin"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Data.Database/obj"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Processes/bin"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Processes/obj"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.InterfaceTest/bin"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.InterfaceTest/obj"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.UnitTest/bin"; IsDirectory = $true },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.UnitTest/obj"; IsDirectory = $true },
        # D-12: Conf.Database/tools/mergeSSDTScripts.ps1 - moved to Data.Database/tools/install/
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/tools/mergeSSDTScripts.ps1"; IsDirectory = $false }
    )
}

function Get-TextLineMutationMappings {
    # Returns plain-text line-removal descriptors. {{ProjectName}} resolved by Plan-Migration.
    # LinePattern is a regex matched against each line; matching lines are removed.
    return @(
        [pscustomobject]@{ RelativePath = ".gitignore"; MutationId = "RemovePublishXmlIgnore"; LinePattern = '\*\.\[Pp\]ublish\.xml' }
    )
}

function Get-TextLineAppendMappings {
    # Returns plain-text line-append descriptors. Line is appended to file if not already present.
    return @(
        [pscustomobject]@{ RelativePath = ".gitignore"; MutationId = "AddScriptIgnore"; Line = "script/" }
    )
}

function New-TextLineMutationAction {
    param(
        [string]$TargetPath,
        [string]$MutationId,
        [string]$LinePattern
    )
    # Already applied when the pattern is absent (or file doesn't exist)
    $alreadyApplied = $true
    if (Test-Path $TargetPath) {
        $content = Get-Content -Path $TargetPath -Raw -Encoding UTF8
        $alreadyApplied = $content -notmatch $LinePattern
    }
    return [pscustomobject]@{
        ActionType     = "TextLineRemove"
        TargetPath     = $TargetPath
        MutationId     = $MutationId
        LinePattern    = $LinePattern
        AlreadyApplied = $alreadyApplied
    }
}

function New-TextLineAppendAction {
    param(
        [string]$TargetPath,
        [string]$MutationId,
        [string]$Line
    )
    $alreadyApplied = $false
    if (Test-Path $TargetPath) {
        $existingLines = @(Get-Content -Path $TargetPath -Encoding UTF8)
        $alreadyApplied = $existingLines -contains $Line
    }
    return [pscustomobject]@{
        ActionType     = "TextLineAppend"
        TargetPath     = $TargetPath
        MutationId     = $MutationId
        Line           = $Line
        AlreadyApplied = $alreadyApplied
    }
}

function Apply-TextLineMutation {
    param([pscustomobject]$Action)
    if (-not (Test-Path $Action.TargetPath)) {
        Write-Warning-Custom "Text mutation target not found (skipped): $($Action.TargetPath)"
        return
    }
    $lines = Get-Content -Path $Action.TargetPath -Encoding UTF8
    $filtered = @($lines | Where-Object { $_ -notmatch $Action.LinePattern })
    [System.IO.File]::WriteAllLines($Action.TargetPath, $filtered, [System.Text.UTF8Encoding]::new($false))
    Write-Success "Text-mutated ($($Action.MutationId)): $($Action.TargetPath)"
}

function Apply-TextLineAppend {
    param([pscustomobject]$Action)
    $lines = if (Test-Path $Action.TargetPath) {
        @(Get-Content -Path $Action.TargetPath -Encoding UTF8)
    }
    else {
        @()
    }
    $lines += $Action.Line
    [System.IO.File]::WriteAllLines($Action.TargetPath, $lines, [System.Text.UTF8Encoding]::new($false))
    Write-Success "Text-appended ($($Action.MutationId)): $($Action.TargetPath)"
}

# ── Phase 8: TextReplace mutation system ──────────────────────────────────────

function Get-TextReplaceMappings {
    # Returns regex-based text replacement descriptors. {{ProjectName}} resolved by Plan-Migration.
    # OldPattern is a regex matched against file content; matching text is replaced with NewText.
    return @(
        [pscustomobject]@{
            RelativePath = "{{ProjectName}}.Conf.Database/scripts/Script.PostDeployment.sql"
            MutationId   = "ParametrizeCreateOrUpdateDatabase"
            OldPattern   = '(?m)^[ \t]*EXEC\s+pNet_CreateOrUpdateDatabase\s+(?!.*\$\(OriginDatabaseName\)).*$'
            NewText      = "`tEXEC pNet_CreateOrUpdateDatabase `$(OriginDatabaseName), N'`$(CurrentDacVersion)', N'`$(ProjectName)'"
        }
    )
}

function New-TextReplaceAction {
    param(
        [string]$TargetPath,
        [string]$MutationId,
        [string]$OldPattern,
        [string]$NewText
    )
    $alreadyApplied = $true
    if (Test-Path $TargetPath) {
        $content = Get-Content -Path $TargetPath -Raw -Encoding UTF8
        $alreadyApplied = $content -notmatch $OldPattern
    }
    return [pscustomobject]@{
        ActionType     = "TextReplace"
        TargetPath     = $TargetPath
        MutationId     = $MutationId
        OldPattern     = $OldPattern
        NewText        = $NewText
        AlreadyApplied = $alreadyApplied
    }
}

function Apply-TextReplace {
    param([pscustomobject]$Action)
    if (-not (Test-Path $Action.TargetPath)) {
        Write-Warning-Custom "TextReplace target not found (skipped): $($Action.TargetPath)"
        return
    }
    $content = Get-Content -Path $Action.TargetPath -Raw -Encoding UTF8
    $newContent = $content -replace $Action.OldPattern, $Action.NewText
    [System.IO.File]::WriteAllText($Action.TargetPath, $newContent, [System.Text.UTF8Encoding]::new($false))
    Write-Success "Text-replaced ($($Action.MutationId)): $($Action.TargetPath)"
}

function Get-XmlMutationMappings {
    # Returns per-file XML mutation descriptors. {{ProjectName}} resolved by Plan-Migration.
    # MutationId values: "SkipPostSharp" | "ConfItemGroups" | "TypeScriptCompileRemove" |
    #                    "FlexygoParentDatabasePackage" | "SqlCmdVariableDefaults" | "RemoveInstallMapJsonRef" |
    #                    "RemoveProjectGuid" | "RemoveTargetDatabaseSet" | "RemoveRenameMe" |
    #                    "RemoveFolderEntry" | "RemoveMailLicenseRef" | "EnsureDboSubFolders" |
    #                    "EnsureDataDatabaseNoneIncludes"
    return @(
        # ── Backend ──────────────────────────────────────────────────────────────────
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Backend/{{ProjectName}}.Backend.csproj"; MutationId = "SkipPostSharp" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Backend/{{ProjectName}}.Backend.csproj"; MutationId = "ConfItemGroups" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Backend/{{ProjectName}}.Backend.csproj"; MutationId = "RemoveInstallMapJsonRef" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Backend/{{ProjectName}}.Backend.csproj"; MutationId = "RemoveMailLicenseRef" },
        # ── Frontend ─────────────────────────────────────────────────────────────────
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Frontend/{{ProjectName}}.Frontend.csproj"; MutationId = "SkipPostSharp" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Frontend/{{ProjectName}}.Frontend.csproj"; MutationId = "ConfItemGroups" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Frontend/{{ProjectName}}.Frontend.csproj"; MutationId = "TypeScriptCompileRemove" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Frontend/{{ProjectName}}.Frontend.csproj"; MutationId = "RemoveInstallMapJsonRef" },
        # ── Processes ────────────────────────────────────────────────────────────────
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Processes/{{ProjectName}}.Processes.csproj"; MutationId = "SkipPostSharp" },
        # ── Conf.Database ────────────────────────────────────────────────────────────
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/{{ProjectName}}.Conf.Database.sqlproj"; MutationId = "FlexygoParentDatabasePackage" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/{{ProjectName}}.Conf.Database.sqlproj"; MutationId = "SqlCmdVariableDefaults" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/{{ProjectName}}.Conf.Database.sqlproj"; MutationId = "RemoveInstallMapJsonRef" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/{{ProjectName}}.Conf.Database.sqlproj"; MutationId = "RemoveProjectGuid" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/{{ProjectName}}.Conf.Database.sqlproj"; MutationId = "RemoveTargetDatabaseSet" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/{{ProjectName}}.Conf.Database.sqlproj"; MutationId = "RemoveRenameMe" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/{{ProjectName}}.Conf.Database.sqlproj"; MutationId = "RemoveFolderEntry"; ExtraData = @{ Include = "scripts\" } },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/{{ProjectName}}.Conf.Database.sqlproj"; MutationId = "RemoveFolderEntry"; ExtraData = @{ Include = "scripts\staticdata\" } },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/{{ProjectName}}.Conf.Database.sqlproj"; MutationId = "RemoveFolderEntry"; ExtraData = @{ Include = "dbo\" } },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Conf.Database/{{ProjectName}}.Conf.Database.sqlproj"; MutationId = "EnsureDboSubFolders" },
        # ── Data.Database ────────────────────────────────────────────────────────────
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Data.Database/{{ProjectName}}.Data.Database.sqlproj"; MutationId = "RemoveInstallMapJsonRef" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Data.Database/{{ProjectName}}.Data.Database.sqlproj"; MutationId = "RemoveProjectGuid" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Data.Database/{{ProjectName}}.Data.Database.sqlproj"; MutationId = "RemoveTargetDatabaseSet" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Data.Database/{{ProjectName}}.Data.Database.sqlproj"; MutationId = "RemoveRenameMe" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Data.Database/{{ProjectName}}.Data.Database.sqlproj"; MutationId = "RemoveFolderEntry"; ExtraData = @{ Include = "scripts\staticdata\" } },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Data.Database/{{ProjectName}}.Data.Database.sqlproj"; MutationId = "RemoveFolderEntry"; ExtraData = @{ Include = "dbo\" } },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Data.Database/{{ProjectName}}.Data.Database.sqlproj"; MutationId = "RemoveFolderEntry"; ExtraData = @{ Include = "scripts\" } },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Data.Database/{{ProjectName}}.Data.Database.sqlproj"; MutationId = "EnsureDboSubFolders" },
        [pscustomobject]@{ RelativePath = "{{ProjectName}}.Data.Database/{{ProjectName}}.Data.Database.sqlproj"; MutationId = "EnsureDataDatabaseNoneIncludes" }
    )
}

function New-XmlMutationAction {
    param(
        [string]$TargetPath,
        [string]$MutationId,
        [hashtable]$ExtraData = @{}
    )
    $alreadyApplied = $false
    if (Test-Path $TargetPath) {
        try {
            $xml = [xml](Get-Content -Path $TargetPath -Raw -Encoding UTF8)
            $alreadyApplied = switch ($MutationId) {
                "SkipPostSharp" { $null -ne $xml.SelectSingleNode("//PropertyGroup/SkipPostSharp") }
                "ConfItemGroups" {
                    $(
                        $null -ne $xml.SelectSingleNode('//ItemGroup/Folder[@Include="conf\"]') -and
                        $null -ne $xml.SelectSingleNode('//ItemGroup/Content[@Remove="conf\**"]') -and
                        $null -ne $xml.SelectSingleNode('//ItemGroup/Content[@Include="conf\**\*.*"]')
                    ) 
                }
                "TypeScriptCompileRemove" { $null -ne $xml.SelectSingleNode('//ItemGroup/TypeScriptCompile[@Remove]') }
                "FlexygoParentDatabasePackage" {
                    $null -ne $xml.SelectSingleNode("//PropertyGroup/FlexygoParentDatabasePackage")
                }
                "SqlCmdVariableDefaults" {
                    $(
                        # Applied when ProjectName DefaultValue and CurrentDacVersion are no longer the MSBuild references
                        $projNameNode = $xml.SelectSingleNode('//SqlCmdVariable[@Include="ProjectName"]/DefaultValue')
                        $dacVersionNode = $xml.SelectSingleNode('//SqlCmdVariable[@Include="CurrentDacVersion"]/DefaultValue')
                        $null -ne $projNameNode -and $projNameNode.InnerText -ne '$(DacApplicationName)' -and
                        $null -ne $dacVersionNode -and $dacVersionNode.InnerText -ne '$(DefaultDacVersion)'
                    ) 
                }
                "RemoveInstallMapJsonRef" {
                    # Applied when the Content element is already absent
                    $null -eq $xml.SelectSingleNode('//Content[@Include="install.map.json"]')
                }
                "RemoveProjectGuid" {
                    # Applied when ProjectGuid element is already absent from PropertyGroup
                    $null -eq $xml.SelectSingleNode("//PropertyGroup/ProjectGuid")
                }
                "RemoveTargetDatabaseSet" {
                    # Applied when TargetDatabaseSet element is already absent from PropertyGroup
                    $null -eq $xml.SelectSingleNode("//PropertyGroup/TargetDatabaseSet")
                }
                "RemoveRenameMe" {
                    # Applied when no None element with .nuspec.RENAME_ME suffix is present
                    $null -eq $xml.SelectSingleNode('//None[contains(@Include, ".nuspec.RENAME_ME")]')
                }
                "RemoveFolderEntry" {
                    # Applied when the specific Folder Include value is already absent
                    $includeVal = $ExtraData["Include"]
                    $null -eq $xml.SelectSingleNode("//ItemGroup/Folder[@Include='$includeVal']")
                }
                "RemoveMailLicenseRef" {
                    # Applied when MailLicense.xml Content element is already absent
                    $null -eq $xml.SelectSingleNode('//Content[@Include="MailLicense.xml"]')
                }
                "EnsureDboSubFolders" {
                    $(
                        # Applied when all 4 dbo sub-folder entries are already present
                        $null -ne $xml.SelectSingleNode('//ItemGroup/Folder[@Include="dbo\Database Triggers\"]') -and
                        $null -ne $xml.SelectSingleNode('//ItemGroup/Folder[@Include="dbo\Functions\"]') -and
                        $null -ne $xml.SelectSingleNode('//ItemGroup/Folder[@Include="dbo\Views\"]') -and
                        $null -ne $xml.SelectSingleNode('//ItemGroup/Folder[@Include="dbo\User Defined Types\"]')
                    ) 
                }
                "EnsureDataDatabaseNoneIncludes" {
                    $projectName = $ExtraData["ProjectName"]
                    $(
                        $null -ne $xml.SelectSingleNode("//ItemGroup/None[@Include='buildTransitive\$projectName.Data.Database.props']") -and
                        $null -ne $xml.SelectSingleNode("//ItemGroup/None[@Include='buildTransitive\$projectName.Data.Database.targets']") -and
                        $null -ne $xml.SelectSingleNode("//ItemGroup/None[@Include='tools\install\mergeSSDTScripts.ps1']")
                    )
                }
                default { $false }
            }
        }
        catch {
            Write-Warning-Custom "Could not parse $TargetPath for mutation check: $_"
        }
    }
    return [pscustomobject]@{
        ActionType     = "XmlMutate"
        TargetPath     = $TargetPath
        MutationId     = $MutationId
        AlreadyApplied = $alreadyApplied
        ExtraData      = $ExtraData
    }
}

function Apply-XmlMutation {
    param([pscustomobject]$Action)
    try {
        if (-not (Test-Path $Action.TargetPath)) {
            Write-Warning-Custom "Mutation target not found (skipped): $($Action.TargetPath)"
            return
        }

        $rawContent = Get-Content -Path $Action.TargetPath -Raw -Encoding UTF8
        $xml = [xml]$rawContent
        $hasDeclaration = $xml.FirstChild -is [System.Xml.XmlDeclaration]

        switch ($Action.MutationId) {
            "SkipPostSharp" {
                $pg = $xml.SelectSingleNode("//PropertyGroup")
                if ($null -eq $pg) { throw "No <PropertyGroup> found in $($Action.TargetPath)" }
                $el = $xml.CreateElement("SkipPostSharp")
                $el.InnerText = "true"
                $pg.AppendChild($el) | Out-Null
            }
            "ConfItemGroups" {
                # ItemGroup 1: Folder Include
                $ig1 = $xml.CreateElement("ItemGroup")
                $folder = $xml.CreateElement("Folder")
                $folder.SetAttribute("Include", "conf\")
                $ig1.AppendChild($folder) | Out-Null

                # ItemGroup 2: Content Remove
                $ig2 = $xml.CreateElement("ItemGroup")
                $contentRemove = $xml.CreateElement("Content")
                $contentRemove.SetAttribute("Remove", "conf\**")
                $ig2.AppendChild($contentRemove) | Out-Null

                # ItemGroup 3: Content Include with copy settings
                $ig3 = $xml.CreateElement("ItemGroup")
                $contentInclude = $xml.CreateElement("Content")
                $contentInclude.SetAttribute("Include", "conf\**\*.*")
                $contentInclude.SetAttribute("Exclude", "conf\**\*.local.*")
                $copyOut = $xml.CreateElement("CopyToOutputDirectory")
                $copyOut.InnerText = "Never"
                $copyPub = $xml.CreateElement("CopyToPublishDirectory")
                $copyPub.InnerText = "PreserveNewest"
                $contentInclude.AppendChild($copyOut) | Out-Null
                $contentInclude.AppendChild($copyPub) | Out-Null
                $ig3.AppendChild($contentInclude) | Out-Null

                $xml.DocumentElement.AppendChild($ig1) | Out-Null
                $xml.DocumentElement.AppendChild($ig2) | Out-Null
                $xml.DocumentElement.AppendChild($ig3) | Out-Null
            }
            "TypeScriptCompileRemove" {
                $ig = $xml.CreateElement("ItemGroup")
                $tsCompile = $xml.CreateElement("TypeScriptCompile")
                $tsCompile.SetAttribute("Remove", "wwwroot\**\*.d.ts")
                $ig.AppendChild($tsCompile) | Out-Null
                $xml.DocumentElement.AppendChild($ig) | Out-Null
            }
            "FlexygoParentDatabasePackage" {
                # D-02: append 5-line comment + element as last children of first PropertyGroup
                $pg = $xml.SelectSingleNode("//PropertyGroup")
                if ($null -eq $pg) { throw "No <PropertyGroup> found in $($Action.TargetPath)" }
                $commentText = " Padre directo en la cadena snowball: el merge script (propagado`n         via buildTransitive/ desde el package L0) usa esto como filtro para`n         seleccionar solo el dacpac del padre directo (que ya contiene la`n         cadena previa mergeada). El generador del template sustituye el`n         token Flexygo.Conf.Database por el nombre real del padre. "
                $comment = $xml.CreateComment($commentText)
                $pg.AppendChild($comment) | Out-Null
                $el = $xml.CreateElement("FlexygoParentDatabasePackage")
                $el.InnerText = "Flexygo.Conf.Database"
                $pg.AppendChild($el) | Out-Null
            }
            "SqlCmdVariableDefaults" {
                # D-03: replace MSBuild references in ProjectName and CurrentDacVersion DefaultValue
                if (-not $Action.ExtraData -or -not $Action.ExtraData.ContainsKey("ProjectName")) {
                    throw "SqlCmdVariableDefaults mutation requires ExtraData.ProjectName"
                }
                $projectName = $Action.ExtraData["ProjectName"]

                $projNameNode = $xml.SelectSingleNode('//SqlCmdVariable[@Include="ProjectName"]/DefaultValue')
                if ($null -ne $projNameNode) { $projNameNode.InnerText = $projectName }

                $dacVersionNode = $xml.SelectSingleNode('//SqlCmdVariable[@Include="CurrentDacVersion"]/DefaultValue')
                if ($null -ne $dacVersionNode) { $dacVersionNode.InnerText = "1.0.0.0" }
            }
            "RemoveInstallMapJsonRef" {
                # D-04: smart removal - entire ItemGroup if sole child, else just the Content element
                $contentNode = $xml.SelectSingleNode('//Content[@Include="install.map.json"]')
                if ($null -ne $contentNode) {
                    $parent = $contentNode.ParentNode
                    # Count only element children (ignore whitespace text nodes)
                    $elementChildren = @($parent.ChildNodes | Where-Object { $_ -is [System.Xml.XmlElement] })
                    if ($elementChildren.Count -eq 1) {
                        $parent.ParentNode.RemoveChild($parent) | Out-Null
                    }
                    else {
                        $parent.RemoveChild($contentNode) | Out-Null
                    }
                }
            }
            "RemoveProjectGuid" {
                # D-08: remove <ProjectGuid> from PropertyGroup (element only - no ItemGroup involved)
                $targetNode = $xml.SelectSingleNode("//PropertyGroup/ProjectGuid")
                if ($null -ne $targetNode) {
                    $targetNode.ParentNode.RemoveChild($targetNode) | Out-Null
                }
            }
            "RemoveTargetDatabaseSet" {
                # D-09: remove <TargetDatabaseSet> from PropertyGroup (element only)
                $targetNode = $xml.SelectSingleNode("//PropertyGroup/TargetDatabaseSet")
                if ($null -ne $targetNode) {
                    $targetNode.ParentNode.RemoveChild($targetNode) | Out-Null
                }
            }
            "RemoveRenameMe" {
                # D-01: remove <None Include="...nuspec.RENAME_ME" /> with smart ItemGroup removal
                $targetNode = $xml.SelectSingleNode('//None[contains(@Include, ".nuspec.RENAME_ME")]')
                if ($null -ne $targetNode) {
                    $parent = $targetNode.ParentNode
                    $elementChildren = @($parent.ChildNodes | Where-Object { $_ -is [System.Xml.XmlElement] })
                    if ($elementChildren.Count -eq 1) {
                        $parent.ParentNode.RemoveChild($parent) | Out-Null
                    }
                    else {
                        $parent.RemoveChild($targetNode) | Out-Null
                    }
                }
            }
            "RemoveFolderEntry" {
                # D-05: remove <Folder Include="<ExtraData.Include>" /> with smart ItemGroup removal
                $includeVal = $Action.ExtraData["Include"]
                if ([string]::IsNullOrEmpty($includeVal)) {
                    throw "RemoveFolderEntry mutation requires ExtraData.Include"
                }
                $targetNode = $xml.SelectSingleNode("//ItemGroup/Folder[@Include='$includeVal']")
                if ($null -ne $targetNode) {
                    $parent = $targetNode.ParentNode
                    $elementChildren = @($parent.ChildNodes | Where-Object { $_ -is [System.Xml.XmlElement] })
                    if ($elementChildren.Count -eq 1) {
                        $parent.ParentNode.RemoveChild($parent) | Out-Null
                    }
                    else {
                        $parent.RemoveChild($targetNode) | Out-Null
                    }
                }
            }
            "RemoveMailLicenseRef" {
                # D-07: remove <Content Include="MailLicense.xml"> with smart ItemGroup removal
                $targetNode = $xml.SelectSingleNode('//Content[@Include="MailLicense.xml"]')
                if ($null -ne $targetNode) {
                    $parent = $targetNode.ParentNode
                    $elementChildren = @($parent.ChildNodes | Where-Object { $_ -is [System.Xml.XmlElement] })
                    if ($elementChildren.Count -eq 1) {
                        $parent.ParentNode.RemoveChild($parent) | Out-Null
                    }
                    else {
                        $parent.RemoveChild($targetNode) | Out-Null
                    }
                }
            }
            "EnsureDboSubFolders" {
                # D-04: append missing dbo sub-folder Folder entries to the existing Folder ItemGroup
                $folderItemGroup = $xml.SelectSingleNode("//ItemGroup[Folder]")
                if ($null -eq $folderItemGroup) {
                    throw "EnsureDboSubFolders: No ItemGroup with Folder elements found in $($Action.TargetPath)"
                }
                $foldersToEnsure = @(
                    "dbo\Database Triggers\",
                    "dbo\Functions\",
                    "dbo\Views\",
                    "dbo\User Defined Types\"
                )
                foreach ($folderInclude in $foldersToEnsure) {
                    $existing = $xml.SelectSingleNode("//ItemGroup/Folder[@Include='$folderInclude']")
                    if ($null -eq $existing) {
                        $newFolder = $xml.CreateElement("Folder")
                        $newFolder.SetAttribute("Include", $folderInclude)
                        $folderItemGroup.AppendChild($newFolder) | Out-Null
                    }
                }
            }
            "EnsureDataDatabaseNoneIncludes" {
                if (-not $Action.ExtraData -or -not $Action.ExtraData.ContainsKey("ProjectName")) {
                    throw "EnsureDataDatabaseNoneIncludes mutation requires ExtraData.ProjectName"
                }
                $projectName = $Action.ExtraData["ProjectName"]
                $noneItemGroup = $xml.SelectSingleNode("//ItemGroup[None]")
                if ($null -eq $noneItemGroup) {
                    throw "EnsureDataDatabaseNoneIncludes: No ItemGroup with None elements found in $($Action.TargetPath)"
                }
                $includesToEnsure = @(
                    "buildTransitive\$projectName.Data.Database.props",
                    "buildTransitive\$projectName.Data.Database.targets",
                    "tools\install\mergeSSDTScripts.ps1"
                )
                foreach ($include in $includesToEnsure) {
                    $existing = $xml.SelectSingleNode("//ItemGroup/None[@Include='$include']")
                    if ($null -eq $existing) {
                        $newNone = $xml.CreateElement("None")
                        $newNone.SetAttribute("Include", $include)
                        $noneItemGroup.AppendChild($newNone) | Out-Null
                    }
                }
            }
        }

        $settings = [System.Xml.XmlWriterSettings]::new()
        $settings.Indent = $true
        $settings.IndentChars = "    "
        $settings.Encoding = [System.Text.UTF8Encoding]::new($false)
        $settings.OmitXmlDeclaration = -not $hasDeclaration

        $writer = [System.Xml.XmlWriter]::Create($Action.TargetPath, $settings)
        try {
            $xml.Save($writer)
        }
        finally {
            $writer.Dispose()
        }

        Write-Success "Mutated ($($Action.MutationId)): $($Action.TargetPath)"
    }
    catch {
        throw
    }
}

function Plan-Migration {
    param(
        [string]$TemplateRootPath,
        [string]$EffectiveProjectName,
        [string]$EffectiveTargetVersion
    )

    Write-Log "Phase 2: Building migration plan..."

    if (-not (Test-Path $TemplateRootPath)) {
        throw "Template directory not found: $TemplateRootPath"
    }

    $actions = @()
    $mappings = Get-TemplateMappings

    foreach ($mapping in $mappings) {
        $templatePath = Join-Path $TemplateRootPath $mapping.Template
        if (-not (Test-Path $templatePath)) {
            throw "Missing template: $templatePath"
        }

        $resolvedRelativeDestination = $mapping.Destination.Replace("{{ProjectName}}", $EffectiveProjectName)
        $destinationPath = Join-Path $ProjectPath $resolvedRelativeDestination

        $templateContent = Get-Content -Path $templatePath -Raw -Encoding UTF8
        $rendered = Get-ParametrizedContent -TemplateContent $templateContent -EffectiveProjectName $EffectiveProjectName -EffectiveTargetVersion $EffectiveTargetVersion

        $actions += New-MigrationAction -TemplatePath $templatePath -DestinationPath $destinationPath -RenderedContent $rendered
    }

    # Phase 3: merge deletion mappings inline
    $deletionMappings = Get-DeletionMappings
    foreach ($delMapping in $deletionMappings) {
        $resolvedRelative = $delMapping.RelativePath.Replace("{{ProjectName}}", $EffectiveProjectName)
        $targetPath = Join-Path $ProjectPath $resolvedRelative

        # Security: ensure resolved path stays within $ProjectPath (path-escape guard)
        $resolvedProject = (Resolve-Path $ProjectPath).Path
        if (-not $targetPath.StartsWith($resolvedProject)) {
            Write-Warning-Custom "Deletion target escapes project root (skipped): $targetPath"
            continue
        }

        $actions += New-DeletionAction -TargetPath $targetPath -IsDirectory $delMapping.IsDirectory
    }

    # Phase 4: merge XML mutation mappings inline
    $mutationMappings = Get-XmlMutationMappings
    foreach ($mutMapping in $mutationMappings) {
        $resolvedRelative = $mutMapping.RelativePath.Replace("{{ProjectName}}", $EffectiveProjectName)
        $targetPath = Join-Path $ProjectPath $resolvedRelative

        # Security: ensure resolved path stays within $ProjectPath (path-escape guard)
        $resolvedProject = (Resolve-Path $ProjectPath).Path
        if (-not $targetPath.StartsWith($resolvedProject)) {
            Write-Warning-Custom "Mutation target escapes project root (skipped): $targetPath"
            continue
        }

        $extraData = if ($mutMapping.PSObject.Properties['ExtraData'] -and $mutMapping.ExtraData) { $mutMapping.ExtraData } else { @{} }
        if ($mutMapping.MutationId -eq "SqlCmdVariableDefaults" -or $mutMapping.MutationId -eq "EnsureDataDatabaseNoneIncludes") {
            $extraData = @{ ProjectName = $EffectiveProjectName }
        }
        $actions += New-XmlMutationAction -TargetPath $targetPath -MutationId $mutMapping.MutationId -ExtraData $extraData
    }

    # Phase 5 (text): remove .gitignore lines that conflict with migrated files
    $textMutationMappings = Get-TextLineMutationMappings
    foreach ($textMapping in $textMutationMappings) {
        $resolvedRelative = $textMapping.RelativePath.Replace("{{ProjectName}}", $EffectiveProjectName)
        $targetPath = Join-Path $ProjectPath $resolvedRelative

        # Security: ensure resolved path stays within $ProjectPath (path-escape guard)
        $resolvedProject = (Resolve-Path $ProjectPath).Path
        if (-not $targetPath.StartsWith($resolvedProject)) {
            Write-Warning-Custom "Text mutation target escapes project root (skipped): $targetPath"
            continue
        }

        $actions += New-TextLineMutationAction -TargetPath $targetPath -MutationId $textMapping.MutationId -LinePattern $textMapping.LinePattern
    }

    # Phase 6 (text append): add .gitignore entries required by migrated layout
    $textAppendMappings = Get-TextLineAppendMappings
    foreach ($appendMapping in $textAppendMappings) {
        $resolvedRelative = $appendMapping.RelativePath.Replace("{{ProjectName}}", $EffectiveProjectName)
        $targetPath = Join-Path $ProjectPath $resolvedRelative

        # Security: ensure resolved path stays within $ProjectPath (path-escape guard)
        $resolvedProject = (Resolve-Path $ProjectPath).Path
        if (-not $targetPath.StartsWith($resolvedProject)) {
            Write-Warning-Custom "Text append target escapes project root (skipped): $targetPath"
            continue
        }

        $actions += New-TextLineAppendAction -TargetPath $targetPath -MutationId $appendMapping.MutationId -Line $appendMapping.Line
    }

    # Phase 8 (text replace): apply regex-based text replacements
    $textReplaceMappings = Get-TextReplaceMappings
    foreach ($trMapping in $textReplaceMappings) {
        $resolvedRelative = $trMapping.RelativePath.Replace("{{ProjectName}}", $EffectiveProjectName)
        $targetPath = Join-Path $ProjectPath $resolvedRelative

        # Security: ensure resolved path stays within $ProjectPath (path-escape guard)
        $resolvedProject = (Resolve-Path $ProjectPath).Path
        if (-not $targetPath.StartsWith($resolvedProject)) {
            Write-Warning-Custom "TextReplace target escapes project root (skipped): $targetPath"
            continue
        }

        $actions += New-TextReplaceAction -TargetPath $targetPath -MutationId $trMapping.MutationId -OldPattern $trMapping.OldPattern -NewText $trMapping.NewText
    }

    return $actions
}

function Show-MigrationPlan {
    param([array]$Actions)

    Write-Host ""
    Write-Host "Migration Plan" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor DarkGray

    foreach ($action in $Actions) {
        if ($action.ActionType -eq "Delete") {
            if ($action.TargetExists) {
                Write-Host "[DELETE] $($action.TargetPath)"
            }
            else {
                Write-Host "[SKIP]   $($action.TargetPath) (already absent)"
            }
            continue
        }

        if ($action.ActionType -eq "XmlMutate") {
            if ($action.AlreadyApplied) {
                Write-Host "[SKIP]   $($action.TargetPath) ($($action.MutationId) already applied)"
            }
            else {
                Write-Host "[MUTATE] $($action.TargetPath) ($($action.MutationId))"
            }
            continue
        }

        if ($action.ActionType -eq "TextLineRemove") {
            if ($action.AlreadyApplied) {
                Write-Host "[SKIP]   $($action.TargetPath) ($($action.MutationId) already applied)"
            }
            else {
                Write-Host "[MUTATE] $($action.TargetPath) ($($action.MutationId))"
            }
            continue
        }

        if ($action.ActionType -eq "TextLineAppend") {
            if ($action.AlreadyApplied) {
                Write-Host "[SKIP]   $($action.TargetPath) ($($action.MutationId) already applied)"
            }
            else {
                Write-Host "[MUTATE] $($action.TargetPath) ($($action.MutationId))"
            }
            continue
        }

        if ($action.ActionType -eq "TextReplace") {
            if ($action.AlreadyApplied) {
                Write-Host "[SKIP]   $($action.TargetPath) ($($action.MutationId) already applied)"
            }
            else {
                Write-Host "[MUTATE] $($action.TargetPath) ($($action.MutationId))"
            }
            continue
        }

        if (-not $action.RequiresWrite) {
            Write-Host "[SKIP]   $($action.DestinationPath) (already up-to-date)"
        }
        elseif ($action.DestinationExists) {
            Write-Host "[UPDATE] $($action.DestinationPath)"
        }
        else {
            Write-Host "[CREATE] $($action.DestinationPath)"
        }
    }

    $writeCount = @($Actions | Where-Object { $_.ActionType -eq "Copy" -and $_.RequiresWrite }).Count
    $updateCount = @($Actions | Where-Object { $_.ActionType -eq "Copy" -and $_.RequiresWrite -and $_.DestinationExists }).Count
    $createCount = @($Actions | Where-Object { $_.ActionType -eq "Copy" -and $_.RequiresWrite -and -not $_.DestinationExists }).Count
    $skipCount = @($Actions | Where-Object { $_.ActionType -eq "Copy" -and -not $_.RequiresWrite }).Count
    $deleteCount = @($Actions | Where-Object { $_.ActionType -eq "Delete" -and $_.TargetExists }).Count
    $absentCount = @($Actions | Where-Object { $_.ActionType -eq "Delete" -and -not $_.TargetExists }).Count
    $mutateCount = @($Actions | Where-Object { ($_.ActionType -eq "XmlMutate" -or $_.ActionType -eq "TextLineRemove" -or $_.ActionType -eq "TextLineAppend" -or $_.ActionType -eq "TextReplace") -and -not $_.AlreadyApplied }).Count
    $mutateSkipCount = @($Actions | Where-Object { ($_.ActionType -eq "XmlMutate" -or $_.ActionType -eq "TextLineRemove" -or $_.ActionType -eq "TextLineAppend" -or $_.ActionType -eq "TextReplace") -and $_.AlreadyApplied }).Count

    Write-Host ""
    Write-Host "Summary: $writeCount copy change(s) | $createCount create | $updateCount update | $skipCount copy-skip | $deleteCount delete | $absentCount already-absent | $mutateCount mutate | $mutateSkipCount mutate-skip" -ForegroundColor Cyan
}

function Apply-Action {
    param([pscustomobject]$Action)

    $parentDir = Split-Path -Parent $Action.DestinationPath
    if (-not (Test-Path $parentDir)) {
        New-Item -Path $parentDir -ItemType Directory -Force | Out-Null
        Write-Log "Directory created: $parentDir"
    }

    [System.IO.File]::WriteAllText($Action.DestinationPath, $Action.RenderedContent, [System.Text.UTF8Encoding]::new($false))
    Write-Success "Written: $($Action.DestinationPath)"
}

function Execute-Migration {
    param(
        [array]$Actions,
        [bool]$IsDryRun
    )

    $pendingActions = @($Actions | Where-Object {
            ($_.ActionType -eq "Copy" -and $_.RequiresWrite) -or
            ($_.ActionType -eq "Delete" -and $_.TargetExists) -or
            ($_.ActionType -eq "XmlMutate" -and -not $_.AlreadyApplied) -or
            ($_.ActionType -eq "TextLineRemove" -and -not $_.AlreadyApplied) -or
            ($_.ActionType -eq "TextLineAppend" -and -not $_.AlreadyApplied) -or
            ($_.ActionType -eq "TextReplace" -and -not $_.AlreadyApplied)
        })
    if ($pendingActions.Count -eq 0) {
        Write-Success "No changes required. Project is already aligned with templates."
        return
    }

    if ($IsDryRun) {
        foreach ($action in $pendingActions) {
            if ($action.ActionType -eq "Delete") {
                Write-Log "[DRY-RUN] Would delete: $($action.TargetPath)"
                continue
            }
            if ($action.ActionType -eq "XmlMutate") {
                Write-Log "[DRY-RUN] Would mutate ($($action.MutationId)): $($action.TargetPath)"
                continue
            }
            if ($action.ActionType -eq "TextLineRemove") {
                Write-Log "[DRY-RUN] Would text-mutate ($($action.MutationId)): $($action.TargetPath)"
                continue
            }
            if ($action.ActionType -eq "TextLineAppend") {
                Write-Log "[DRY-RUN] Would text-append ($($action.MutationId)): $($action.TargetPath)"
                continue
            }
            if ($action.ActionType -eq "TextReplace") {
                Write-Log "[DRY-RUN] Would text-replace ($($action.MutationId)): $($action.TargetPath)"
                continue
            }
            if ($action.DestinationExists) {
                Write-Log "[DRY-RUN] Would backup/write: $($action.DestinationPath)"
            }
            else {
                Write-Log "[DRY-RUN] Would create: $($action.DestinationPath)"
            }
        }
        Write-Success "Dry-run completed. No files were modified."
        return
    }

    foreach ($action in $pendingActions) {
        if ($action.ActionType -eq "Delete") {
            if (-not (Test-Path $action.TargetPath)) {
                Write-Log "[SKIP] Already absent: $($action.TargetPath)"
            }
            elseif ($action.IsDirectory) {
                Remove-DirectoryForcefully -Path $action.TargetPath
                Write-Success "Deleted: $($action.TargetPath)"
            }
            else {
                Remove-Item -Path $action.TargetPath -Force
                Write-Success "Deleted: $($action.TargetPath)"
            }
            continue
        }
        if ($action.ActionType -eq "XmlMutate") {
            Apply-XmlMutation -Action $action
            continue
        }
        if ($action.ActionType -eq "TextLineRemove") {
            Apply-TextLineMutation -Action $action
            continue
        }
        if ($action.ActionType -eq "TextLineAppend") {
            Apply-TextLineAppend -Action $action
            continue
        }
        if ($action.ActionType -eq "TextReplace") {
            Apply-TextReplace -Action $action
            continue
        }
        Apply-Action -Action $action
    }

    $copyDone = @($pendingActions | Where-Object { $_.ActionType -eq "Copy" }).Count
    $deleteDone = @($pendingActions | Where-Object { $_.ActionType -eq "Delete" }).Count
    $mutateDone = @($pendingActions | Where-Object { $_.ActionType -eq "XmlMutate" -or $_.ActionType -eq "TextLineRemove" -or $_.ActionType -eq "TextLineAppend" -or $_.ActionType -eq "TextReplace" }).Count
    Write-Success "Apply completed. $copyDone file(s) copied/updated, $deleteDone target(s) deleted, $mutateDone mutation(s) applied."
}

Write-Host ""
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host " Flexygo Migration Tool (master -> develop)" -ForegroundColor Cyan
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host ""

$ProjectPath = (Resolve-Path $ProjectPath).Path
$script:LOG_FILE = Join-Path $ProjectPath ("migration-log-{0}.txt" -f (Get-Date -Format "yyyyMMdd-HHmmss"))

$isDryRun = $DryRun.IsPresent

Write-Log "Project Path: $ProjectPath"
Write-Log "Mode: $(if ($isDryRun) { 'Dry-Run' } else { 'Apply' })"

try {
    if (-not (Test-ProjectPath)) {
        throw "Validation failed"
    }

    $ProjectName = Detect-ProjectName
    if (-not $ProjectName) {
        throw "ProjectName is required"
    }

    Ensure-GitIgnoreScriptEntry -Path $ProjectPath
    Ensure-GitRepository -Path $ProjectPath

    if (-not (Validate-Preconditions)) {
        throw "Preconditions not met"
    }

    # Auto-detect TargetVersion from project when not explicitly provided
    if (-not $TargetVersion) {
        $detectedVersion = Detect-FlexygoVersion -ProjectName $ProjectName -ProjectPath $ProjectPath
        if ($detectedVersion) {
            $TargetVersion = $detectedVersion
            Write-Success "Auto-detected TargetVersion: $TargetVersion"
        }
        else {
            Write-Error-Custom "Could not auto-detect Flexygo version. Please specify -TargetVersion explicitly."
            throw "TargetVersion is required"
        }
    }

    Write-Log "Target Version: $TargetVersion"

    $templateRoot = Resolve-TemplateRoot
    $plan = Plan-Migration -TemplateRootPath $templateRoot -EffectiveProjectName $ProjectName -EffectiveTargetVersion $TargetVersion
    Show-MigrationPlan -Actions $plan

    if (-not $isDryRun) {
        $pendingCount = @($plan | Where-Object {
                ($_.ActionType -eq "Copy" -and $_.RequiresWrite) -or
                ($_.ActionType -eq "Delete" -and $_.TargetExists) -or
                ($_.ActionType -eq "XmlMutate" -and -not $_.AlreadyApplied) -or
                ($_.ActionType -eq "TextLineRemove" -and -not $_.AlreadyApplied) -or
                ($_.ActionType -eq "TextLineAppend" -and -not $_.AlreadyApplied) -or
                ($_.ActionType -eq "TextReplace" -and -not $_.AlreadyApplied)
            }).Count
        if ($pendingCount -gt 0) {
            Write-Host ""
            $confirmation = Read-Host "Apply $pendingCount change(s)? Type 'yes' or 'y' to continue"
            if ($confirmation -notin @("yes", "y", "Y")) {
                Write-Warning-Custom "Migration canceled by user before apply."
                $isDryRun = $true
            }
        }
    }

    Execute-Migration -Actions $plan -IsDryRun $isDryRun

    if (-not $isDryRun) {
        Write-Host ""
        Write-Log "Running: flexygo-product update -s ./"
        Push-Location $ProjectPath
        try {
            & flexygo-product update -s ./
            if ($LASTEXITCODE -ne 0) {
                Write-Warning-Custom "flexygo-product update exited with code $LASTEXITCODE. Check the output above."
            }
            else {
                Write-Success "flexygo-product update completed successfully."
            }
        }
        finally {
            Pop-Location
        }
    }

    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Cyan
    Write-Host "  1. Run dotnet build"
    Write-Host "  2. Commit the migration"
    Write-Host "  3. See docs/migration-master-to-develop.md"
}
catch {
    Write-Error-Custom "Migration failed: $_"
    exit 1
}
finally {
    Save-LogFile
}

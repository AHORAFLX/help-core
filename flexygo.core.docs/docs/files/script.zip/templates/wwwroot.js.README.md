# JavaScript personalizado — {{ProjectName}}

Coloca aquí los archivos JavaScript propios del producto.

Estos archivos se sirven estáticamente desde `wwwroot/{{ProjectName}}/js/`.

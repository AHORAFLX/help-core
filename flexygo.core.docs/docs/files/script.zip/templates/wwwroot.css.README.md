# CSS personalizado — {{ProjectName}}

Coloca aquí las hojas de estilo propias del producto.

Estos archivos se sirven estáticamente desde `wwwroot/{{ProjectName}}/css/`.
